import smtplib

def send_email(receiver_email_addr,message):
	s = smtplib.SMTP('smtp.gmail.com', 587) 
	s.starttls()
	s.login("pythonemailtest11@gmail.com", "Python@123")
	message = message
	s.sendmail("pythonemailtest11@gmail.com", receiver_email_addr, message) 
	s.quit() 
    #return 'Success'