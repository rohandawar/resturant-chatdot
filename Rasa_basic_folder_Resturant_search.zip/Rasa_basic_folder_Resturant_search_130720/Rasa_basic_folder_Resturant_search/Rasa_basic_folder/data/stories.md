############################# STORIES WITH ALL VALID PARAMS AND SEND MAIL NOT CHOESN ############################ 

## Story_1
* greet
    - utter_greet
* restaurant_search{"location": "Lucknow"}
    - slot{"location": "Lucknow"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "Lucknow"}
    - slot{"cuisine": "Mexican"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## Story_2
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "Mumbai"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "Mumbai"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "Mumbai"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## story_3
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "Mumbai", "price": "more than 700"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "Mumbai"}
    - slot{"price": "more than 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "Mumbai"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## Story_4
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Chinese"}
    - slot{"cuisine": "Chinese"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "Mumbai"}
    - slot{"cuisine": "Chinese"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## story_5
* greet
    - utter_greet
* restaurant_search{"price": "less than 300", "location": "faridabad"}
    - slot{"location": "faridabad"}
    - slot{"price": "less than 300"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_search_restaurants
    - slot{"location": "faridabad"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "less than 300"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## story_6
* greet
    - utter_greet
* restaurant_search{"price": "300 to 700", "location": "goa"}
    - slot{"location": "goa"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_search_restaurants
    - slot{"location": "goa"}
    - slot{"cuisine": "Italian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## story_7
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_location
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "bangalore"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## story_8
* greet
    - utter_greet
* restaurant_search{"price": "more than 700", "location": "delhi"}
    - slot{"location": "delhi"}
    - slot{"price": "more than 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_search_restaurants
    - slot{"location": "delhi"}
    - slot{"cuisine": "north indian"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* deny
    - utter_goodbye
    - action_restart


############################# STORIES WITH INVALID LOCATION############################ 
	
## story_invalid_location_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "mirzapur"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "mirzapur"}
    - action_validate_location
    - slot{"loc_avl": "0"}
    - utter_do_not_operate
    - utter_goodbye
    - action_restart

## story_invalid_location_2
* greet
    - utter_greet
* restaurant_search{"location": "wasseypur"}
    - slot{"location": "wasseypur"}
    - action_validate_location
    - slot{"loc_avl": "0"}
    - utter_do_not_operate
    - utter_goodbye
    - action_restart

## story_invalid_location_3
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "wasseypur"}
    - slot{"location": "wasseypur"}
    - action_validate_location
    - slot{"loc_avl": "0"}
    - utter_do_not_operate
    - utter_goodbye
    - action_restart

  
    
    

################# INTERACTIVE STORIES #####################

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "south indian", "location": "indore", "price": "more than 700"}
    - slot{"cuisine": "south indian"}
    - slot{"location": "indore"}
    - slot{"price": "more than 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart
    
    

## interactive_story_2
* greet
    - utter_greet
* restaurant_search{"cuisine": "mexican", "location": "indore", "price": "300 to 700"}
    - slot{"cuisine": "mexican"}
    - slot{"location": "indore"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "mexican"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart
    



## interactive_story_3
* greet
    - utter_greet
* restaurant_search{"cuisine": "mexican", "location": "pakistan"}
    - slot{"cuisine": "mexican"}
    - slot{"location": "pakistan"}
    - action_validate_location
    - slot{"loc_avl": "0"}
    - utter_do_not_operate
    - utter_goodbye
    - action_restart

## interactive_story_4
* greet
    - utter_greet
* restaurant_search{"cuisine": "american", "location": "africa"}
    - slot{"cuisine": "american"}
    - slot{"location": "africa"}
    - action_validate_location
    - slot{"loc_avl": "0"}
    - utter_do_not_operate
    - utter_goodbye
    - action_restart

## interactive_story_5
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "africa"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "africa"}
    - action_validate_location
    - slot{"loc_avl": "0"}
    - utter_do_not_operate
    - utter_goodbye
    - action_restart



## interactive_story_6
* greet
    - utter_greet
* restaurant_search{"cuisine": "italian", "location": "africa"}
    - slot{"cuisine": "italian"}
    - slot{"location": "africa"}
    - action_validate_location
    - slot{"loc_avl": "0"}
    - utter_do_not_operate
    - utter_goodbye
    - action_restart

## interactive_story_7
* greet
    - utter_greet
* restaurant_search{"cuisine": "North Indian", "location": "africa"}
    - slot{"cuisine": "North Indian"}
    - slot{"location": "africa"}
    - action_validate_location
    - slot{"loc_avl": "0"}
    - utter_do_not_operate
    - utter_goodbye
    - action_restart

## interactive_story_8
* greet
    - utter_greet
* restaurant_search{"cuisine": "South Indian", "location": "africa"}
    - slot{"cuisine": "South Indian"}
    - slot{"location": "africa"}
    - action_validate_location
    - slot{"loc_avl": "0"}
    - utter_do_not_operate
    - utter_goodbye
    - action_restart


## interactive_story_9
* greet
    - utter_greet
* restaurant_search{"cuisine": "american", "location": "indore", "price": "300 to 700"}
    - slot{"cuisine": "american"}
    - slot{"location": "indore"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "american"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart


## interactive_story_10
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "indore", "price": "300 to 700"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "indore"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart


## interactive_story_11
* greet
    - utter_greet
* restaurant_search{"cuisine": "south indian", "location": "indore", "price": "300 to 700"}
    - slot{"cuisine": "south indian"}
    - slot{"location": "indore"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart


## interactive_story_12
* greet
    - utter_greet
* restaurant_search{"cuisine": "north indian", "location": "indore", "price": "300 to 700"}
    - slot{"cuisine": "north indian"}
    - slot{"location": "indore"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "north indian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart
## interactive_story_13
* greet
    - utter_greet
* restaurant_search{"cuisine": "rajasthani", "location": "jaipur"}
    - slot{"cuisine": "rajasthani"}
    - slot{"location": "jaipur"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "0"}
    - utter_wrongcuisine_try_again
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "less than 300"}
    - slot{"price": "less than 300"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "jaipur"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "less than 300"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - utter_restart
    - action_restart

## interactive_story_14
* greet
    - utter_greet
* restaurant_search{"cuisine": "rajasthani", "location": "jaipur", "price": "less than 300"}
    - slot{"cuisine": "rajasthani"}
    - slot{"location": "jaipur"}
    - slot{"price": "less than 300"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "0"}
    - utter_wrongcuisine_try_again
    - utter_ask_cuisine
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "jaipur"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "less than 300"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_15
* greet
    - utter_greet
* restaurant_search{"cuisine": "Mugalalai", "location": "jaipur", "price": "less than 300"}
    - slot{"cuisine": "Mugalalai"}
    - slot{"location": "jaipur"}
    - slot{"price": "less than 300"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "0"}
    - utter_wrongcuisine_try_again
    - utter_ask_cuisine
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "jaipur"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "less than 300"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_16
* greet
    - utter_greet
* restaurant_search{"cuisine": "persian", "location": "jaipur", "price": "less than 300"}
    - slot{"cuisine": "persian"}
    - slot{"location": "jaipur"}
    - slot{"price": "less than 300"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "0"}
    - utter_wrongcuisine_try_again
    - utter_ask_cuisine
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "jaipur"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "less than 300"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_17
* greet
    - utter_greet
* restaurant_search{"cuisine": "continental", "location": "jaipur", "price": "less than 300"}
    - slot{"cuisine": "continental"}
    - slot{"location": "jaipur"}
    - slot{"price": "less than 300"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "0"}
    - utter_wrongcuisine_try_again
    - utter_ask_cuisine
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "jaipur"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "less than 300"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_18
* greet
    - utter_greet
* restaurant_search{"cuisine": "continental", "location": "jaipur", "price": "less than 400"}
    - slot{"cuisine": "continental"}
    - slot{"location": "jaipur"}
    - slot{"price": "less than 400"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "0"}
    - utter_wrongcuisine_try_again
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "0"}
    - utter_invalid_price
    - utter_ask_budget
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "jaipur"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "less than 300"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart


## interatcive_story_19
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
* restaurant_search{"price": "less than 300"}
    - slot{"price": "less than 300"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "less than 300"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart
   
## interatcive_story_20
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart
   
## interatcive_story_20
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart
## interactive_story_21
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "less than 300"}
    - slot{"price": "less than 300"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "less than 300"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_22
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_22
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart


## interactive_story_23
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "mexican"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_24
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "american"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_24
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "italian"}
    - slot{"cuisine": "italian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "italian"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_25
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_26
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "north indian"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart
##################################STORIES WITH EMAIL###############################

## interactive_story_27
* greet
    - utter_greet
* restaurant_search{"cuisine": "mexican", "location": "indore", "price": "300 to 700"}
    - slot{"cuisine": "mexican"}
    - slot{"location": "indore"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "mexican"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
*email{"emailid": "rohan.dawar@gmail.com"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_28
* greet
    - utter_greet
* restaurant_search{"cuisine": "american", "location": "Mumbai", "price": "less than 300"}
    - slot{"cuisine": "american"}
    - slot{"location": "Mumbai"}
    - slot{"price": "less than 300"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "Mumbai"}
    - slot{"cuisine": "american"}
    - slot{"price": "less than 300"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "abc@mail.com"}
    - slot{"emailid": "abc@mail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_29
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "indore"}
    - slot{"location": "indore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "north indian"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "def.353@mail.com"}
    - slot{"emailid": "def.353@mail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_30
* greet
    - utter_greet
* restaurant_search{"cuisine": "south indian", "location": "indore", "price": "more than 700"}
    - slot{"cuisine": "south indian"}
    - slot{"location": "indore"}
    - slot{"price": "more than 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "amail@bmail.com"}
    - slot{"emailid": "amail@bmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_31
* greet
    - utter_greet
* restaurant_search{"cuisine": "mexican", "location": "indore", "price": "300 to 700"}
    - slot{"cuisine": "mexican"}
    - slot{"location": "indore"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "mexican"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "newmail@fmail.com"}
    - slot{"emailid": "newmail@fmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_32
* greet
    - utter_greet
* restaurant_search{"cuisine": "american", "location": "indore", "price": "300 to 700"}
    - slot{"cuisine": "american"}
    - slot{"location": "indore"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "american"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "bmail@amail.com"}
    - slot{"emailid": "bmail@amail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_33
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "indore", "price": "300 to 700"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "indore"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "cmail@amail.com"}
    - slot{"emailid": "cmail@amail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_34
* greet
    - utter_greet
* restaurant_search{"cuisine": "south indian", "location": "indore", "price": "300 to 700"}
    - slot{"cuisine": "south indian"}
    - slot{"location": "indore"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "indore"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "dmail@amail.com"}
    - slot{"emailid": "dmail@amail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_35
* greet
    - utter_greet
* restaurant_search{"cuisine": "north indian", "location": "hyderabad", "price": "300 to 700"}
    - slot{"cuisine": "north indian"}
    - slot{"location": "hyderabad"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "hyderabad"}
    - slot{"cuisine": "north indian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "email@amail.com"}
    - slot{"emailid": "email@amail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_37
* greet
    - utter_greet
* restaurant_search{"cuisine": "rajasthani", "location": "agra"}
    - slot{"cuisine": "rajasthani"}
    - slot{"location": "agra"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "0"}
    - utter_wrongcuisine_try_again
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "agra"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "fmail@amail.com"}
    - slot{"emailid": "fmail@amail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_37
* greet
    - utter_greet
* restaurant_search{"cuisine": "rajasthani", "location": "agra"}
    - slot{"cuisine": "rajasthani"}
    - slot{"location": "agra"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "0"}
    - utter_wrongcuisine_try_again
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "less than 300"}
    - slot{"price": "less than 300"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "agra"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "less than 300"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "fmail@amail.com"}
    - slot{"emailid": "fmail@amail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_38
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "pune"}
    - slot{"location": "pune"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "pune"}
    - slot{"cuisine": "American"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* email{"emailid": "aaa@mcmail.com"}
    - slot{"emailid": "aaa@mcmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_39
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "amritsar"}
    - slot{"location": "amritsar"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "amritsar"}
    - slot{"cuisine": "American"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* email{"emailid": "aaa@mcmail.com"}
    - slot{"emailid": "aaa@mcmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_40
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bareilly"}
    - slot{"location": "bareilly"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "bareilly"}
    - slot{"cuisine": "American"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* email{"emailid": "aaa@mcmail.com"}
    - slot{"emailid": "aaa@mcmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_41
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bhavnagar"}
    - slot{"location": "bhavnagar"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "bhavnagar"}
    - slot{"cuisine": "American"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* email{"emailid": "aaa@mcmail.com"}
    - slot{"emailid": "aaa@mcmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_42
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bokarosteelcity"}
    - slot{"location": "bokarosteelcity"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "bokarosteelcity"}
    - slot{"cuisine": "American"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* email{"emailid": "aaa@mcmail.com"}
    - slot{"emailid": "aaa@mcmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_43
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "jammu"}
    - slot{"location": "jammu"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "jammu"}
    - slot{"cuisine": "American"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* email{"emailid": "aaa@mcmail.com"}
    - slot{"emailid": "aaa@mcmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart


## interactive_story_44
* greet{"greet": "hola"}
    - utter_greet
* restaurant_search{"location": "jhansi"}
    - slot{"location": "jhansi"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "jhansi"}
    - slot{"cuisine": "American"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* email{"emailid": "dfk.dtk@mailmail.com"}
    - slot{"emailid": "dfk.dtk@mailmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart


## interactive_story_45
* greet{"greet": "hola"}
    - utter_greet
* restaurant_search{"location": "aurangabad"}
    - slot{"location": "aurangabad"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "aurangabad"}
    - slot{"cuisine": "American"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* email{"emailid": "dfk.dtk@mailmail.com"}
    - slot{"emailid": "dfk.dtk@mailmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart


## interactive_story_46
* greet{"greet": "hola"}
    - utter_greet
* restaurant_search{"location": "bareilly"}
    - slot{"location": "bareilly"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "bareilly"}
    - slot{"cuisine": "American"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* email{"emailid": "dfk.dtk@mailmail.com"}
    - slot{"emailid": "dfk.dtk@mailmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart


## interactive_story_47
* greet{"greet": "hola"}
    - utter_greet
* restaurant_search{"location": "dhanbad"}
    - slot{"location": "dhanbad"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "dhanbad"}
    - slot{"cuisine": "American"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* email{"emailid": "dfk.dtk@mailmail.com"}
    - slot{"emailid": "dfk.dtk@mailmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart


## interactive_story_47
* greet{"greet": "hola"}
    - utter_greet
* restaurant_search{"location": "erode"}
    - slot{"location": "erode"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "erode"}
    - slot{"cuisine": "American"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* email{"emailid": "dfk.dtk@mailmail.com"}
    - slot{"emailid": "dfk.dtk@mailmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_48
* greet
    - utter_greet
* restaurant_search{"price": "less than 300", "location": "faridabad"}
    - slot{"location": "faridabad"}
    - slot{"price": "less than 300"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_search_restaurants
    - slot{"location": "faridabad"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "less than 300"}
    - utter_ask_sendmail
* email{"emailid": "mememe@ggmail.com"}
    - slot{"emailid": "mememe@ggmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart


## interactive_story_49
* greet
    - utter_greet
* restaurant_search{"price": "more than 700", "cuisine": "american", "location": "kolhapur"}
    - slot{"cuisine": "american"}
    - slot{"location": "kolhapur"}
    - slot{"price": "more than 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "kolhapur"}
    - slot{"cuisine": "american"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "funtosh@hmail.com"}
    - slot{"emailid": "funtosh@hmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_50
* greet
    - utter_greet
* restaurant_search{"price": "more than 700", "cuisine": "mexican", "location": "mathura"}
    - slot{"cuisine": "mexican"}
    - slot{"location": "mathura"}
    - slot{"price": "more than 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "mathura"}
    - slot{"cuisine": "mexican"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "gggd@jmail.com"}
    - slot{"emailid": "gggd@jmail.com"}
    - actions_SendMail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_51
* email{"location": "meerut"}
    - slot{"location": "meerut"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_get_email
* email{"emailid": "drakep1102@gmail.com"}
    - slot{"emailid": "drakep1102@gmail.com"}
    - actions_SendMail
    - slot{"location": "meerut"}
    - slot{"cuisine": "north indian"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "drakep1102@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_52
* email{"location": "surat", "cuisine": "south indian", "price": "300 to 700"}
    - slot{"cuisine": "south indian"}
    - slot{"location": "surat"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_get_email
* email{"emailid": "drakep1102@gmail.com"}
    - slot{"emailid": "drakep1102@gmail.com"}
    - actions_SendMail
    - slot{"location": "surat"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "drakep1102@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_53
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "asansol"}
    - slot{"location": "asansol"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "asansol"}
    - slot{"cuisine": "north indian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* email{"emailid": "dawar.rohan@gmail.com"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - actions_SendMail
    - slot{"location": "asansol"}
    - slot{"cuisine": "north indian"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_54
* greet
    - utter_greet
* restaurant_search{"price": "300 to 700", "location": "goa"}
    - slot{"location": "goa"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_search_restaurants
    - slot{"location": "goa"}
    - slot{"cuisine": "Italian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "ankit@gmail.com"}
    - slot{"emailid": "ankit@gmail.com"}
    - actions_SendMail
    - slot{"location": "goa"}
    - slot{"cuisine": "Italian"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "ankit@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_55
* greet
    - utter_greet
* restaurant_search{"price": "less than 300", "location": "bangalore"}
    - slot{"location": "bangalore"}
    - slot{"price": "less than 300"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_search_restaurants
    - slot{"location": "bangalore"}
    - slot{"cuisine": "Mexican"}
    - slot{"price": "less than 300"}
    - utter_ask_sendmail
* email{"emailid": "dawar.rohan@gmail.com"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - actions_SendMail
    - slot{"location": "bangalore"}
    - slot{"cuisine": "Mexican"}
    - slot{"price": "less than 300"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_56
* greet
    - utter_greet
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "less than 300"}
    - slot{"price": "less than 300"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "bangalore"}
    - slot{"cuisine": "Mexican"}
    - slot{"price": "less than 300"}
    - slot{"rest_avl": "0"}
    - utter_goodbye
    - action_restart

## interactive_story_57
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_location
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "bangalore"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* email{"emailid": "dfss@gmail.com"}
    - slot{"emailid": "dfss@gmail.com"}
    - actions_SendMail
    - slot{"location": "bangalore"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "dfss@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_58
* greet
    - utter_greet
* restaurant_search{"cuisine": "american", "location": "kota", "price": "more than 700"}
    - slot{"cuisine": "american"}
    - slot{"location": "kota"}
    - slot{"price": "more than 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"rest_avl": "0"}
    - utter_goodbye
    - action_restart

## interactive_story_59
* greet
    - utter_greet
* restaurant_search{"cuisine": "mexican", "location": "pakistan"}
    - slot{"cuisine": "mexican"}
    - slot{"location": "pakistan"}
    - action_validate_location
    - slot{"loc_avl": "0"}
    - utter_do_not_operate
    - utter_goodbye
    - action_restart

## interactive_story_60
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "warangal"}
    - slot{"location": "warangal"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"rest_avl": "0"}
    - utter_goodbye
    - action_restart


## interactive_story_61
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bokarosteelcity"}
    - slot{"location": "bokarosteelcity"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"rest_avl": "0"}
    - utter_goodbye
    - action_restart


## interactive_story_62
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "guntur"}
    - slot{"location": "guntur"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Mexican"}
    - slot{"cuisine": "Mexican"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"rest_avl": "0"}
    - utter_goodbye
    - action_restart

## interactive_story_63
* greet
    - utter_greet
* restaurant_search{"price": "less than 300", "location": "delhi"}
    - slot{"location": "delhi"}
    - slot{"price": "less than 300"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_search_restaurants
    - slot{"rest_avl": "0"}
    - utter_goodbye
    - action_restart

## interactive_story_64
* greet
    - utter_greet
* restaurant_search{"price": "more than 700", "location": "delhi"}
    - slot{"location": "delhi"}
    - slot{"price": "more than 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_search_restaurants
    - slot{"location": "delhi"}
    - slot{"cuisine": "north indian"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "rohan.dawar@nokia.com"}
    - slot{"emailid": "rohan.dawar@nokia.com"}
    - actions_SendMail
    - slot{"location": "delhi"}
    - slot{"cuisine": "north indian"}
    - slot{"price": "more than 700"}
    - slot{"emailid": "rohan.dawar@nokia.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_65
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "bangalore"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* email{"emailid": "dawar.rohan@gmail.com"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - actions_SendMail
    - slot{"location": "bangalore"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart


## interactive_story_66
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "mangalore"}
    - slot{"location": "mangalore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "mangalore"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* email{"emailid": "dawar.rohan@gmail.com"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - actions_SendMail
    - slot{"location": "mangalore"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart


## interactive_story_67
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "kochi"}
    - slot{"location": "kochi"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "kochi"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* email{"emailid": "dawar.rohan@gmail.com"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - actions_SendMail
    - slot{"location": "kochi"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_68
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "noida"}
    - slot{"location": "noida"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "noida"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* email{"emailid": "dawar.rohan@gmail.com"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - actions_SendMail
    - slot{"location": "noida"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_69
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "vadodara"}
    - slot{"location": "vadodara"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "vadodara"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* email{"emailid": "dawar.rohan@gmail.com"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - actions_SendMail
    - slot{"location": "vadodara"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "dawar.rohan@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart
	
## interactive_story_70
* email{"location": "lucknow"}
    - slot{"location": "lucknow"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_get_email
* email{"emailid": "drakep1102@gmail.com"}
    - slot{"emailid": "drakep1102@gmail.com"}
    - actions_SendMail
    - slot{"location": "lucknow"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "drakep1102@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_71
* email{"location": "Lucknow", "cuisine": "chinese", "price": "300 to 700"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "Lucknow"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_get_email
* email{"emailid": "drakep1102@gmail.com"}
    - slot{"emailid": "drakep1102@gmail.com"}
    - actions_SendMail
    - slot{"location": "Lucknow"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "drakep1102@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_72
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "American"}
    - slot{"cuisine": "American"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "Mumbai"}
    - slot{"cuisine": "American"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_73
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Mumbai"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Chinese"}
    - slot{"cuisine": "American"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "Bangalore"}
    - slot{"cuisine": "Chinese"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_74
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "colombo"}
    - slot{"location": "colombo"}
    - action_validate_location
    - slot{"loc_avl": "0"}
    - utter_do_not_operate
    - utter_goodbye
    - action_restart

## interactive_story_75
* greet
    - utter_greet
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Anything"}
    - slot{"cuisine": "Anything"}
    - action_validate_cuisine
    - slot{"csn_avl": "0"}
    - utter_do_not_operate
    - utter_goodbye
    - action_restart

## interactive_story_76
* greet
    - utter_greet
* restaurant_search{"location": "Bhopal"}
    - slot{"location": "Bhopal"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "Italian"}
    - slot{"cuisine": "Italian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* email{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "Bhopal"}
    - slot{"cuisine": "Italian"}
    - slot{"price": "300 to 700"}
    - utter_ask_sendmail
* affirm
    - utter_get_email
* email{"emailid": "drakep1102@gmail.com"}
    - slot{"emailid": "drakep1102@gmail.com"}
    - actions_SendMail
    - slot{"location": "Bhopal"}
    - slot{"cuisine": "Italian"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "drakep1102@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_77
* email{"emailid": "drakep1102@gmail.com"}
    - slot{"emailid": "drakep1102@gmail.com"}
    - utter_ask_location
* restaurant_search{"location": "Lucknow"}
    - slot{"location": "Lucknow"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* email{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - actions_SendMail
    - slot{"location": "Lucknow"}
    - slot{"cuisine": "north indian"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "drakep1102@gmail.com"}
    - utter_ask_sendmail
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_78
* greet
    - utter_greet
* restaurant_search{"location": "Bhopal", "cuisine": "Italian", "price": "300 to 700"}
    - slot{"cuisine": "Italian"}
    - slot{"location": "Bhopal"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_get_email
* email{"emailid": "askeme@gmail.com"}
    - slot{"emailid": "askeme@gmail.com"}
    - actions_SendMail
    - slot{"location": "Bhopal"}
    - slot{"cuisine": "Italian"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "askeme@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_79
* restaurant_search{"cuisine": "Italian", "location": "Bangalore"}
    - slot{"cuisine": "Italian"}
    - slot{"location": "Bangalore"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "Bangalore"}
    - slot{"cuisine": "Italian"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_80
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Lucknow"}
    - slot{"location": "Lucknow"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "more than 700"}
    - slot{"price": "more than 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_search_restaurants
    - slot{"location": "Lucknow"}
    - slot{"cuisine": "north indian"}
    - slot{"price": "more than 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_81
* greet
    - utter_greet
* email{"location": "delhi", "cuisine": "American", "price": "300 to 700", "emailid": "nextgen@gmail.com"}
    - slot{"cuisine": "American"}
    - slot{"emailid": "nextgen@gmail.com"}
    - slot{"location": "delhi"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - actions_SendMail
    - slot{"location": "delhi"}
    - slot{"cuisine": "American"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "nextgen@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart

## interactive_story_82
* greet
    - utter_greet
* restaurant_search{"price": "below 700"}
    - slot{"price": "below 700"}
    - action_validate_price
    - slot{"prc_avl": "0"}
    - utter_ask_location
* restaurant_search{"location": "Mumbai"}
    - slot{"location": "Mumbai"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_search_restaurants
    - slot{"location": "Mumbai"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "below 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart
	
## interactive_story_83
* greet
    - utter_greet
* restaurant_search{"price": "below 700"}
    - slot{"price": "below 700"}
    - action_validate_price
    - slot{"prc_avl": "0"}
    - utter_ask_location
* restaurant_search{"location": "Bhopal"}
    - slot{"location": "Bhopal"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - action_search_restaurants
    - slot{"location": "Bhopal"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "below 700"}
    - utter_ask_sendmail
* deny
    - utter_goodbye
    - action_restart

## interactive_story_84
* greet
    - utter_greet
* email{"location": "Mumbai", "cuisine": "American", "price": "300 to 700", "emailid": "nextgen@gmail.com"}
    - slot{"cuisine": "American"}
    - slot{"emailid": "nextgen@gmail.com"}
    - slot{"location": "Mumbai"}
    - slot{"price": "300 to 700"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - actions_SendMail
    - slot{"location": "Mumbai"}
    - slot{"cuisine": "American"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "nextgen@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart
## interactive_story_1
* greet
    - utter_greet
* email{"location": "Bhopal"}
    - slot{"location": "Bhopal"}
    - action_validate_location
    - slot{"loc_avl": "1"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - action_validate_cuisine
    - slot{"csn_avl": "1"}
    - utter_ask_budget
* restaurant_search{"price": "300 to 700"}
    - slot{"price": "300 to 700"}
    - action_validate_price
    - slot{"prc_avl": "1"}
    - utter_get_email
* restaurant_search{"emailid": "test@gmail.com"}
    - slot{"emailid": "test@gmail.com"}
    - actions_SendMail
    - slot{"location": "Bhopal"}
    - slot{"cuisine": "south indian"}
    - slot{"price": "300 to 700"}
    - slot{"emailid": "test@gmail.com"}
    - utter_sent_email
    - utter_goodbye
    - action_restart
