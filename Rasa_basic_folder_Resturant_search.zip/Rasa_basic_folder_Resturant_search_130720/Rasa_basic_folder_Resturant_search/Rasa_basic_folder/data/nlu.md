## intent:affirm
- yes
- yep
- yeah
- indeed
- that's right
- ok
- great
- right, thank you
- correct
- great choice
- sounds really good
- thanks
- yes. [gggd@jmail.com](emailid)

## intent:deny
- no
- nope
- na
- na na
- no thanks

## intent:goodbye
- bye
- goodbye
- good bye
- stop
- end
- farewell
- Bye bye
- have a good one

## intent:greet
- hey
- howdy
- hey there
- hello
- hi
- good morning
- good evening
- dear sir
- namaste
- [hola](greet)
- Hi

## intent:restaurant_search
- i'm looking for a place to eat
- I want to grab lunch
- I am searching for a dinner spot
- I am looking for some restaurants in [Delhi](location).
- I am looking for some restaurants in [Bangalore](location)
- show me [chinese](cuisine) restaurants
- show me [chines]{"entity": "cuisine", "value": "chinese"} restaurants in the [New Delhi]{"entity": "location", "value": "Delhi"}
- show me a [mexican](cuisine) place in the [centre](location)
- i am looking for an [indian](cuisine) spot called olaolaolaolaolaola
- search for restaurants
- anywhere in the [west](location)
- I am looking for [asian fusion](cuisine) food
- I am looking a restaurant in [294328](location)
- in [Gurgaon](location)
- [South Indian](cuisine)
- [North Indian](cuisine)
- [Italian](cuisine)
- [Chinese]{"entity": "cuisine", "value": "chinese"}
- [chinese](cuisine)
- [Lithuania](location)
- Oh, sorry, in [Italy](location)
- I’m hungry. Looking out for some good restaurants
- in [delhi](location)
- I am looking for some restaurants in [Mumbai](location)
- I am looking for [mexican indian fusion](cuisine)
- can you book a table in [rome](location) in a [moderate]{"entity": "price", "value": "300 to 700"} price range with [british](cuisine) food for [four]{"entity": "people", "value": "4"} people
- suggest some good restaurants for price <300 {"entity": 'price', "value": "less than 300"}
- suggest some good restaurants for price > 700 {"entity": 'price', "value": "more than 700"}
- [central](location) [indian](cuisine) restaurant
- please help me to find restaurants in [pune](location)
- Please find me a restaurantin [bangalore](location)
- [mumbai](location)
- show me restaurants
- show me restaurant with average price budget of [less than 300](price)
- show me restaurant with average price budget between [rs 300 and 700]{"entity": "price", "value": "300 to 700"}
- show me restaurant with average price budget of [more than rs 700](price)
- please find me [chinese](cuisine) restaurant in [delhi](location)
- can you find me a [chinese](cuisine) restaurant
- [delhi](location)
- please find me a restaurant in [ahmedabad](location)
- please show me a few [italian](cuisine) restaurants in [bangalore](location)
- [Mexican](cuisine)
- [American](cuisine)
- show me restaurant with average price budget of [under rs 300](price)
- show me restaurant with average price budget of [below 300](price)
- show me [mexican](cuisine) resturant [below 300](price) in [mumbai](location)
- find [mexican](cuisine) restaurant
- [bangalore](location)
- find [southindian]{"entity": "cuisine", "value": "south indian"} resturant in [bangalore](location)
- {"price": "[less than 300](price)"}
- please find [southindian]{"entity": "cuisine", "value": "south indian"} restaurant in [bangalore](location) for price [less than 300](price)
- please find [southindian]{"entity": "cuisine", "value": "south indian"} resturant in [bangalore](location) with average price [less than 300](price)
- please find [south indian](cuisine) resturant in [bangalore](location) for price [less than 300](price)
- show me [mexican](cuisine) resturants in [delhi](location)
- show me resturants in [indore](location)
- please find resturant
- {"[price":"less than 300](price)"}
- search [south indian](cuisine) resturants in [indore](location) for price [more than 700](price)
- find [mexican](cuisine) resturant in [indore](location) between [300 to 700](price)
- please find [mexican](cuisine) resaurants in [pakistan](location)
- please find [american](cuisine) resaurants in [pakistan](location)
- please find [italian](cuisine) resaurants in [pakistan](location)
- please find [south indian](cuisine) resaurants in [pakistan](location)
- please find [north indian](cuisine) resaurants in [pakistan](location)
- please find [southindia]{"entity": "cuisine", "value": "south indian"} resaurants in [pakistan](location)
- - please find [northindia]{"entity": "cuisine", "value": "north indian"} resaurants in [pakistan](location)
- find [american](cuisine) resturant in [africa](location)
- find [rajasthani](cuisine) resturants in [jaipur](location)
- [less than 300](price)
- find [fancy]{"entity": "price", "value": "more than 700"} [chinese](cuisine) restaurants in [indore](location)
- - find [fancy]{"entity": "price", "value": "more than 700"} [north indian](cuisine) restaurants in [kota](location)
- find [rajasthani](cuisine) restaurants in [jaipur](location) average price [less than 300](price)
- [South Indian]{"entity": "cuisine", "value": "south indian"}
- find [continental](cuisine) restaurants in [jaipur](location) average price [less than 300](price)
- find [mugalai](cuisine) restaurants in [jaipur](location) average price [less than 300](price)
- find [persian](cuisine) restaurants in [jaipur](location) average price [less than 300](price)
- find [bengali](cuisine) restaurants in [jaipur](location) average price [less than 300](price)
- find restaurant
- [indore](location)
- find resturant
- find [american](cuisine) resaurant in [mumbai]{"entity": "location", "value": "Mumbai"} for price [less than 300](price)
- I'am hungry. Looking out for some good resturants
- I'm hungry. Looking out for some good resturants
- I m hungry, search some restuarants.
- [pune](location)
- [300 to 700](price)
- can you suggest some good resturants in [jhansi](location)
- [more than 700](price)
- suggest some good resturants for price [<300](price)
- suggest some good restaurants for price <[300](price)
- suggest some [economic]{"entity": "price", "value": "less than 300"} restaurants in [faridabad](location)
- [high end]{"entity": "price", "value": "more than 700"}
- suggest some [fancy]{"entity": "price", "value": "more than 700"} [american](cuisine) restaurants in [kolhapur](location)
- find some [high end]{"entity": "price", "value": "more than 700"} [mexican](cuisine) resturant in [mathura](location)
- find resturants
- [asansol](location)
- [North Indian]{"entity": "cuisine", "value": "north indian"}
- [ahmedabad](location)
- [chennai](location)
- [hyderabad](location)
- [kolkata](location)
- [agra](location)
- [ajmer](location)
- [aligarh](location)
- [amravati](location)
- [amritsar](location)
- [aurangabad](location)
- [bareilly](location)
- [belgaum](location)
- [bhavnagar](location)
- [bhiwandi](location)
- [bhopal](location)
- [bhubaneswar](location)
- [bikaner](location)
- [bokarosteelcity](location)
- [chandigarh](location)
- [coimbatore](location)
- [cuttack](location)
- [dehradun](location)
- [dhanbad](location)
- [durgbhilainagar](location)
- [durgapur](location)
- [erode](location)
- [faridabad](location)
- [firozabad](location)
- [ghaziabad](location)
- [gorakhpur](location)
- [gulbarga](location)
- [guntur](location)
- [gurgaon](location)
- [guwahati](location)
- [gwalior](location)
- [hublidharwad](location)
- [jabalpur](location)
- [jaipur](location)
- [jalandhar](location)
- [jammu](location)
- [jamnagar](location)
- [jamshedpur](location)
- [jhansi](location)
- [jodhpur](location)
- [kannur](location)
- [kanpur](location)
- [kakinada](location)
- [kochi](location)
- [kottayam](location)
- [kolhapur](location)
- [kollam](location)
- [kota](location)
- [kozhikode](location)
- [kurnool](location)
- [lucknow](location)
- [ludhiana](location)
- [madurai](location)
- [malappuram](location)
- [mathura](location)
- [goa](location)
- [mangalore](location)
- [meerut](location)
- [moradabad](location)
- [mysore](location)
- [nagpur](location)
- [nanded](location)
- [nashik](location)
- [nellore](location)
- [noida](location)
- [palakkad](location)
- [patna](location)
- [pondicherry](location)
- [prayagraj](location)
- [raipur](location)
- [rajkot](location)
- [rajahmundry](location)
- [ranchi](location)
- [rourkela](location)
- [salem](location)
- [sangli](location)
- [siliguri](location)
- [solapur](location)
- [srinagar](location)
- [sultanpur](location)
- [surat](location)
- [thiruvananthapuram](location)
- [thrissur](location)
- [tiruchirappalli](location)
- [tirunelveli](location)
- [tiruppur](location)
- [ujjain](location)
- [bijapur](location)
- [vadodara](location)
- [varanasi](location)
- [vasaivirarcity](location)
- [vijayawada](location)
- [visakhapatnam](location)
- [warangal](location)
- find [fancy]{"entity": "price", "value": "more than 700"} north indian{"entity": "cuisine", "value": "north indian"} restaurants in [delhi](location)
- find some [mid range]{"entity": "price", "value": "300 to 700"} resturants in [goa](location)
- [ankitajoshi2502@gmail.com](emailid)
- find some [pocket friendly]{"entity": "price", "value": "less than 300"} resturants in [bangalore](location)
- find resturants in [bangalore](location)
- find [chinese](cuisine) restaurants
- find [american](cuisine) restaurants in [kota](location) for budget [more than 700](price)
- find [mexican](cuisine) restaurants in [pakistan](location)
- find restaurants
- find [pocket friendly]{"entity": "price", "value": "less than 300"} resturants in [delhi](location)
- find [fancy]{"entity": "price", "value": "more than 700"} restaurants in [delhi](location)
- Im hungry. Looking out for some good restaurants
- [South Indian]{"entity": "cuisine", "value": "south indian"}
- [300 to 700](price)
- [test@gmail.com](emailid)

## intent:email
- could you send an email?
- send the details to [abc@yahoo.com](emailid)
- send the details to [aaa@gmail.com](emailid)
- [rohan.dawar@gmail.com](emailid)
- please send over email
- [abc@mail.com](emailid)
- please send it to [aaa@mcmail.com](emailid)
- send it to [dfk.dtk@mailmail.com](emailid)
- yes please. send to [mememe@ggmail.com](emailid)
- [funtosh@hmail.com](emailid)
- [drakep1102@gmail.com](emailid)
- [dawar.rohan@gmail.com](emailid)
- [contactus@gmail.com](emailid)
- [yes.dawar.rohan@gmail]{"entity": "emailid", "value": "dawar.rohan@gmail.com"}.com
- please send it on [dawar.rohan@gmail.com](emailid)
- [rohan.dawar@nokia.com](emailid)
- thanks a lot! please send it to [dawar.rohan@gmail.com](emailid)
- send me email with restaurants in [Bhopal](location)

## synonym: 300 to 700
- rs 300 and 700
- between rs. 300 and 700
- between 300 to 700
- medium price
- upto 700 rs
- mid month

## synonym: less than 300
- economic
- cheap
- pocket-friendly
- inexpensive
- <300
- below 300

## synonym: more than 700
- fancy
- more than rs 700
- expensive
- >700
- fine-dine
- finedine
- above 700

## synonym:300 to 700
- mid range

## synonym:4
- four

## synonym:Allahabad
- prayagraj
- Prayagraj
- Allahabad
- allahabad

## synonym:Amritsar
- amritsar
- Amratsar
- amratsar

## synonym:Chandigarh
- chandigarh
- Chandighar
- chandighar

## synonym:Chennai
- chennai
- madras
- Madras

## synonym:Hyderabad
- hyderabad
- Secunderabad
- secunderabad
- cyberabad
- Cyberabad

## synonym:Jamshedpur
- jamshedpur
- Jamsedpur
- jamsedpur

## synonym:Kolkata
- Calcutta
- kolkata
- kolkatta
- calcutta
- calcuta

## synonym:Lucknow
- Lakhanpur

## synonym:Mangalore
- mangalore
- mangaluru
- Mangaluru

## synonym:Mumbai
- mumbai
- Bombay
- bombay

## synonym:Mysore
- mysore
- mysuru
- Mysuru
- kochi
- cochin
- Cochin

## synonym:Nashik
- nashik
- Nasik
- nasik

## synonym:Pondicherry
- pondicherry
- puducherry
- Puducherry

## synonym:Rajahmundry
- rajahmundry
- Rajahmundri
- rajahmundri
- Rajamundry
- rajamundry
- Rajamundri
- rajamundri

## synonym:Rourkela
- rourkela
- Raurkela
- raurkela

## synonym:Thiruvananthapuram
- thiruvananthapuram
- trivandrum
- Trivandrum
- Travancore
- travancore

## synonym:Vadodara
- vadodara
- Vadodra
- vadodra

## synonym:Visakhapatnam
- visakhapatnam
- Vizag
- vizag

## synonym:bangalore
- Bengaluru
- bngalore
- bengalluru
- Bangalor
- bangalore
- bengaluru

## synonym:chinese
- chines
- Chinese
- Chines

## synonym:dawar.rohan@gmail.com
- yes.dawar.rohan@gmail

## synonym:delhi
- New Delhi
- Delhi
- NewDelhi
- Dilli
- Dellhi
- newdelhi
- Newdelhi
- new delhi
- new Delhi
- Delhi NCR

## synonym:less than 300
- pocket friendly

## synonym:mid
- moderate

## synonym:more than 700
- high end

## synonym:north indian
- northindia
- North Indian
- north-indian
- northindian
- north-indina

## synonym:south indian
- southindian
- southindia
- South Indian
- south-indian
- south-indina

## synonym:vegetarian
- veggie
- vegg

## regex: emailid
- "^(\\D\\w.)*@(\\w.*)"

## regex:greet
- hey[^\s]*

## regex:pincode
- [0-9]{6}
